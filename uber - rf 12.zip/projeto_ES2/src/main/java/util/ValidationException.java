package util;

public class ValidationException extends Exception {
    public ValidationException(String msg) { super(msg); }
}
